import React from 'react';
import UseEffecctApi from './CompFetch/UseEffecctApi';

const AppFetch = () => {
  return (
    <>
        <UseEffecctApi/>
    </>
  )
}

export default AppFetch