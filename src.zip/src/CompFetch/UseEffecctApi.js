import React, { useState } from 'react'
// import { useEffect } from 'react'
// import axios from 'axios'



const UseEffecctApi = () => {
    // const getUsers=async()=>{
    //      const response =  await fetch("https://api.github.com/users");
    //     //  console.log(response)
    //     const data = await response.json();
    //     console.log(data)
    // }
    // useEffect(()=>{
    //   getUsers();
    // },[])
   
    // const fetchData = () => {
    //     return fetch("https://jsonplaceholder.typicode.com/users")
    //           .then((response) => response.json())
    //           .then((data) => console.log(data));
    //   }
    
    //   useEffect(() => {
    //     fetchData();
    //   },[])
 
    // 

    // const [user, setUser] = useState([]);
    
    // async function fetchData() {
    //     try {
    //       const response = await axios.get("https://jsonplaceholder.typicode.com/users")
    //       setUser(response.data)
    //     } catch (error) {
    //       console.error(error);
    //     }
    //   }
    //   console.log(user)
    
    //   useEffect(() => {
    //     fetchData();
    //   },[])


  return (
    <div>UseEffecctApi</div>
  )
}

export default UseEffecctApi
